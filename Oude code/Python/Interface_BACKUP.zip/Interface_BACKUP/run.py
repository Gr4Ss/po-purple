import time
from Interface import *
from math import *
interface = Interface()
#interface.ride_distance(314)
#interface.set_engines_speed([255,255,0])
#time.sleep(3)
#interface.set_engines_sped([0,0,0])
interface.ride_polygon(4,50)
#interface.ride_circ3(50)
#time.sleep(10)
#interface.ride_circ3(50)
#time.sleep(10)
#interface.ride_circ2(50)
#interface.rotate(math.pi/2)
