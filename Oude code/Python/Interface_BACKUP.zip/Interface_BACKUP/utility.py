def sign(x):
    return -1 if x < 0 else 1
